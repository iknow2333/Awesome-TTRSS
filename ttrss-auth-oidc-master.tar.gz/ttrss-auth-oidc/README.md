# OIDC authentication plugin

This is a system plugin, it has to be enabled globally through `TTRSS_PLUGINS`.

Sample Authelia configuration:

```yml
identity_providers:
...
- id: test-ttrss
        secret: your-secret-token
        public: false
        scopes:
          - openid
          - email
          - profile
        redirect_uris:
          - "https://example.com/tt-rss"
        userinfo_signing_algorithm: none
        #pre_configured_consent_duration: 30d
```

Plugin configuration (`.env`):

```properties
TTRSS_AUTH_OIDC_NAME=Authelia
TTRSS_AUTH_OIDC_URL=https://auth.example.com/
TTRSS_AUTH_OIDC_CLIENT_ID=test-ttrss
TTRSS_AUTH_OIDC_CLIENT_SECRET=your-secret-token
```

If everything is configured correctly, another login button will appear on the login form, which
you can use to log in through OpenID.
