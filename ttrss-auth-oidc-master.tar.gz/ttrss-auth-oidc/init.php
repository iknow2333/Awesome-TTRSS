<?php
require_once __DIR__ . "/vendor/autoload.php";

use Jumbojett\OpenIDConnectClient;

class Auth_OIDC extends Auth_Base {

	/** redirect user to this URL after logout; .env:
	 * TTRSS_AUTH_OIDC_POST_LOGOUT_URL=http://127.0.0.1/logout-redirect
	 */
	const AUTH_OIDC_POST_LOGOUT_URL = "AUTH_OIDC_POST_LOGOUT_URL";
	const AUTH_OIDC_NAME = "AUTH_OIDC_NAME";
	const AUTH_OIDC_URL = "AUTH_OIDC_URL";
	const AUTH_OIDC_CLIENT_ID = "AUTH_OIDC_CLIENT_ID";
	const AUTH_OIDC_CLIENT_SECRET = "AUTH_OIDC_CLIENT_SECRET";


	/** @var PluginHost $host */
	private $host;

	function about() {
		return array(null,
			"Authenticates against configured OIDC provider",
			"fox",
			true);
	}

	function init($host) {
		Config::add(self::AUTH_OIDC_POST_LOGOUT_URL, "", Config::T_STRING);
		Config::add(self::AUTH_OIDC_NAME, "", Config::T_STRING);
		Config::add(self::AUTH_OIDC_URL, "", Config::T_STRING);
		Config::add(self::AUTH_OIDC_CLIENT_ID, "", Config::T_STRING);
		Config::add(self::AUTH_OIDC_CLIENT_SECRET, "", Config::T_STRING);

		if (Config::get(self::AUTH_OIDC_URL)) {
			$host->add_hook($host::HOOK_AUTH_USER, $this);
			$host->add_hook($host::HOOK_LOGINFORM_ADDITIONAL_BUTTONS, $this);

			if (Config::get(self::AUTH_OIDC_POST_LOGOUT_URL) != "")
				$host->add_hook($host::HOOK_POST_LOGOUT, $this);
		}

		$this->host = $host;
	}

	function is_public_method($method) {
		return $method == "oidc_login";
	}

	public function oidc_login() : void {
		$oidc = new OpenIDConnectClient(Config::get(self::AUTH_OIDC_URL),
			Config::get(self::AUTH_OIDC_CLIENT_ID),
			Config::get(self::AUTH_OIDC_CLIENT_SECRET));

		$oidc->setRedirectURL(Config::get_self_url());
		$oidc->addScope(['openid', 'profile', 'email']);
		$oidc->authenticate();
	}

	function authenticate($login, $password, $service = '') {
		if (!($_SESSION['uid'] ?? false) && ($_REQUEST['code'] ?? false)) {

			$oidc = new OpenIDConnectClient(Config::get(self::AUTH_OIDC_URL),
				Config::get(self::AUTH_OIDC_CLIENT_ID),
				Config::get(self::AUTH_OIDC_CLIENT_SECRET));

			try {
				$oidc->setRedirectURL(Config::get_self_url());
				$oidc->addScope(['openid', 'profile', 'email']);
				$oidc->authenticate();

				$login = $oidc->requestUserInfo("preferred_username");

				$user_id = $this->auto_create_user($login, $password);

				if ($user_id) {
					$name = $oidc->requestUserInfo("name");

					if ($name) {
						$sth = $this->pdo->prepare("UPDATE ttrss_users SET full_name = ? WHERE id = ?");
						$sth->execute([$name, $user_id]);
					}

					$email = $oidc->requestUserInfo("email");

					if ($email) {
						$sth = $this->pdo->prepare("UPDATE ttrss_users SET email = ? WHERE id = ?");
						$sth->execute([$email, $user_id]);
					}
				}

				return $user_id;

			} catch (Exception $e) {
				$_SESSION["login_error_msg"] = 'OIDC: ' . $e->getMessage();
			}
		}

		return false;
	}

	function get_login_js() {
		return file_get_contents(__DIR__ . "/init.js");
	}

	function hook_loginform_additional_buttons() {
		print \Controls\button_tag(T_sprintf('Log in with %s', Config::get(self::AUTH_OIDC_NAME)), '',
			['class' => '', 'onclick' => 'Plugins.Auth_OIDC.login("'.htmlspecialchars($this->host->get_public_method_url($this, "oidc_login")).'")']);
	}

	function hook_post_logout($login, $user_id) {
		return [
			Config::get(self::AUTH_OIDC_POST_LOGOUT_URL)
			];
	}

	function api_version() {
		return 2;
	}

}
